#include <cstdlib>
#include <iostream>
#include "cAluno.h"

using namespace std;

int main(int argc, char** argv) {
    cAluno obj1;
    cout<<obj1.mediaAluno();
    
    return 0;
}

