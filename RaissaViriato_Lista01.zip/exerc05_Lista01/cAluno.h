
#ifndef CALUNO_H
#define CALUNO_H

class cAluno {
public:
    cAluno();
    cAluno(const cAluno& orig);
    virtual ~cAluno();
    
    float n1, n2, n3;
    
    float mediaAluno();
    
private:

};

#endif /* CALUNO_H */

