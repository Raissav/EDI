/* 
Faça um algoritmo que leia as 3 notas de um aluno e calcule a média final deste aluno. 
Considerar que a média é ponderada e que o peso das notas é: 2,3 e 5, respectivamente. 
 */

#include "cAluno.h"
#include <iostream>

using namespace std;

cAluno::cAluno() {
}

cAluno::cAluno(const cAluno& orig) {
}

cAluno::~cAluno() {
}

float cAluno::mediaAluno(){
    
    float media;
    cout<<"Digite a primeira nota:"<<endl;
    cin>>n1;
    cout<<"Digite a segunda nota:"<<endl;
    cin>>n2;
    cout<<"Digite a terceira nota:"<<endl;
    cin>>n3;

    media = ((n1*2)+(n2*3)+(n3*5))/10;
    
    return media;
}