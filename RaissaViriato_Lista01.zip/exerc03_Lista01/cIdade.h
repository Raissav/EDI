#ifndef CIDADE_H
#define CIDADE_H

class cIdade {
public:
    cIdade();
    cIdade(const cIdade& orig);
    virtual ~cIdade();
    
    int diaNasc, anoNasc, mesNasc;
    int anoAtual = 2021;
    int mesAtual = 9;
    int diaAtual = 30;
    
    void lerDados();
    float calcularIdadeDias();

private:

};

#endif /* CIDADE_H */

