#include <cstdlib>
#include <iostream>
#include "cIdade.h"

using namespace std;

int main(int argc, char** argv) {

    cIdade obj1;
    obj1.lerDados();
    cout<< "Sua idade expressa apenas em dias é"<< obj1.calcularIdadeDias();
    
    return 0;
}

