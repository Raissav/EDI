/* 
 Faça um algoritmo que leia a idade de uma pessoa expressa em anos, meses e dias e 
mostre-a expressa apenas em dias.
 */

#include "cIdade.h"
#include <iostream>

using namespace std;

cIdade::cIdade() {
}

cIdade::cIdade(const cIdade& orig) {
}

cIdade::~cIdade() {
}

void cIdade::lerDados(){
        
    cout<<"Digite o ano em que nasceu:"<<endl;
    cin>>anoNasc;
    cout<<"Digite o mes em que nasceu (se jan '1', fev '2', mar '3', ..):"<<endl;
    cin>>mesNasc;
    cout<<"Digite o dia em que nasceu:"<<endl;
    cin>>diaNasc;
      
}

float cIdade::calcularIdadeDias(){
    
    int total, ano, mes, dia;
    ano = anoAtual - anoNasc;
    mes = mesAtual - mesNasc;
    dia = diaAtual - diaNasc;
    total = (ano*365)+(mes*30)+dia;

    return total;
}
