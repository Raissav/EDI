#include <cstdlib>
#include <iostream>
#include "cIdadeDias.h"

using namespace std;

int main(int argc, char** argv) {

    cIdade obj1;
    obj1.lerDados();
    obj1.calcularIdadeDias();
    
    return 0;
}