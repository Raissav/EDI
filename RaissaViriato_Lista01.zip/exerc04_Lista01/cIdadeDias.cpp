/* 
 Faça um algoritmo que leia a idade de uma pessoa expressa em dias e mostre-a 
expressa em anos, meses e dias. 
 */

#include "cIdadeDias.h"
#include <iostream>
#include <math.h>

using namespace std;

cIdade::cIdade() {
}

cIdade::cIdade(const cIdade& orig) {
}

cIdade::~cIdade() {
}

void cIdade::lerDados(){
        
    cout<<"Digite sua idade expressa em dias:"<<endl;
    cin>>dias;
      
}

float cIdade::calcularIdadeDias(){
    
    int anos, meses, diasF;
     
    anos = floor (dias/365);
    meses = floor((dias - (anos *365))/12);
    diasF = floor (dias % 30);
   
    cout<<"Sua idade é igual a "<<anos<<" ano(s) "<<meses<<" mes(es) "<<diasF<<" dia(s)."<<endl;
    
}
