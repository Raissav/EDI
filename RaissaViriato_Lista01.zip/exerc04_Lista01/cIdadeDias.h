#ifndef CIDADEDIAS_H
#define CIDADEDIA_H

class cIdade {
public:
    cIdade();
    cIdade(const cIdade& orig);
    virtual ~cIdade();
    
    int dias;
        
    void lerDados();
    float calcularIdadeDias();

private:

};

#endif /* CIDADE_H */

