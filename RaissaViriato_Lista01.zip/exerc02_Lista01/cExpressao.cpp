#include "cExpressao.h"
#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;

cExpressao::cExpressao() {
}

cExpressao::cExpressao(const cExpressao& orig) {
}

cExpressao::~cExpressao() {
}

void cExpressao::lerDados(){

    cout<<"Digite o valor de A:"<<endl;
    cin>> A;
    cout<<"Digite o valor de B:"<<endl;
    cin>> B;
    cout<<"Digite o valor de C:"<<endl;
    cin>> C;
}

float cExpressao::calcularExpressao(){
    R = pow((A + B),2);
    S = pow((B + C),2);
    D = (R + S)/2;
    
    return D;
}