#include <cstdlib>
#include <iostream>
#include <cstdlib>
#include "cExpressao.h"

using namespace std;

int main(int argc, char** argv) {
    
    cExpressao obj1;
    obj1.lerDados();
    cout<<obj1.calcularExpressao();
    
    return 0;
}

