#ifndef CFABRICA_H
#define CFABRICA_H

class cFabrica {
public:
    cFabrica();
    cFabrica(const cFabrica& orig);
    virtual ~cFabrica();
    
    int tempoSeg;
    void lerDados();
    void calcular();
        
private:

};

#endif /* CFABRICA_H */

