#include <cstdlib>
#include "cFabrica.h"

using namespace std;

int main(int argc, char** argv) {

    cFabrica obj1;
    obj1.lerDados();
    obj1.calcular();
            
    return 0;
}

