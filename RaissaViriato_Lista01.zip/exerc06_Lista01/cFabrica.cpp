/* 
 Faça um algoritmo que leia o tempo de duração de um evento em uma fábrica 
expressa em segundos e mostre-o expresso em horas, minutos e segundos. 
 */

#include "cFabrica.h"
#include <iostream>
#include <math.h>

using namespace std;

cFabrica::cFabrica() {
}

cFabrica::cFabrica(const cFabrica& orig) {
}

cFabrica::~cFabrica() {
}

void cFabrica::lerDados(){
    
    cout<<"Informe o tempo de duração do evento em segundos:"<<endl;
    cin>>tempoSeg;
}

void cFabrica::calcular(){

    int horas, min, seg;
    horas = floor(tempoSeg / 3600);
    min = floor((tempoSeg - (horas * 3600)) / 60);
    seg = floor(tempoSeg % 60);
    
    cout<<"A duração do evento é de "<<horas<<" hora(s) "<<min<<" minuto(s) e "<<seg<<" segundo(s)."<<endl;

}
