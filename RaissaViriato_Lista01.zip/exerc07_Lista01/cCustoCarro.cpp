/* 
 O custo ao consumidor de um carro novo é a soma do custo de fábrica com a 
percentagem do distribuidor e dos impostos (aplicados ao custo de fábrica). Supondo que 
a percentagem do distribuidor seja de 28% e os impostos de 45%, escrever um algoritmo 
que leia o custo de fábrica de um carro e escreva o custo ao consumidor
*/

#include "cCustoCarro.h"
#include <iostream>

using namespace std;

cCustoCarro::cCustoCarro() {
}

cCustoCarro::cCustoCarro(const cCustoCarro& orig) {
}

cCustoCarro::~cCustoCarro() {
}

void cCustoCarro::lerDados(){

    cout<<"Informe o custo de fabrica de um carro:"<<endl;
    cin>>custoFab;

}

float cCustoCarro::calcularCusto(){

    float porcDist, porcImp, custoCons;
    
    porcDist = (28*custoFab)/100;
    porcImp = (45*custoFab)/100;
    custoCons = (porcDist + porcImp + custoFab);

    cout<<"O custo ao consumidor é:"<<custoCons<<endl;

}