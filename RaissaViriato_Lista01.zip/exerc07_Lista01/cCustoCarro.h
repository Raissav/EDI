#ifndef CCUSTOCARRO_H
#define CCUSTOCARRO_H

class cCustoCarro {
public:
    cCustoCarro();
    cCustoCarro(const cCustoCarro& orig);
    virtual ~cCustoCarro();
    
    float custoFab;
    
    void lerDados();
    float calcularCusto();
    
private:

};

#endif /* CCUSTOCARRO_H */

