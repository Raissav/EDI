#include <cstdlib>

#include "cCustoCarro.h"

using namespace std;

int main(int argc, char** argv) {

    cCustoCarro obj1;
    obj1.lerDados();
    obj1.calcularCusto();
            
    return 0;
}

