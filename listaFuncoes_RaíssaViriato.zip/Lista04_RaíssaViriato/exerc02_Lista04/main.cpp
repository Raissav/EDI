#include <cstdlib>
/*
 Escreva uma função que receba 3 notas de um aluno e uma letra. 
 * Se a letra for A a função retorna a média aritmética das notas do aluno,
 * se for P, a sua média ponderada (pesos: 5, 3 e 2)
 */
#include "cAluno.h"

using namespace std;

int main(int argc, char** argv) {

    cAluno *objAluno = new cAluno();
    objAluno->lerDados();
    
    return 0;
}

