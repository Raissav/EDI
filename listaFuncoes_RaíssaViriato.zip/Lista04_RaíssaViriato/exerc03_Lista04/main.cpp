#include <cstdlib>

#include "cValor.h"

using namespace std;

/*
 Faça uma função que recebe um valor inteiro e verifica se o valor é positivo, 
 negativo ou zero. A função deve retornar 1 para valores positivos, -1 para 
 negativos e 0 para o valor 0.
 */

int main(int argc, char** argv) {

    cValor *objValor = new cValor();
    objValor->lerNumero();
    
    return 0;
}


