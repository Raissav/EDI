#include "cValor.h"
#include <iostream>

using namespace std;

cValor::cValor() {
}

cValor::cValor(const cValor& orig) {
}

cValor::~cValor() {
}

void cValor::lerNumero(){
    
    int num;
    cout<<"Digite o valor inteiro:" << endl;
    cin>> num;
        if (num == 0)
        cout<<"0"<<endl;
        else if (num<0)
            cout<<"-1"<<endl;
            else if (num>0)
                cout<<"1"<<endl;
    
}    