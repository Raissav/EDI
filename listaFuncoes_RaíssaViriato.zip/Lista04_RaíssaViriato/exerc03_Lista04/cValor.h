#ifndef CVALOR_H
#define CVALOR_H

class cValor {
public:
    cValor();
    cValor(const cValor& orig);
    virtual ~cValor();
    
    void lerNumero();
    float valorFinal(int n1);
    
private:

};

#endif /* CVALOR_H */
