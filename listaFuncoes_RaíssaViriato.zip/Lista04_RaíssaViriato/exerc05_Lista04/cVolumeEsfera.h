#ifndef CVOLUMEESFERA_H
#define CVOLUMEESFERA_H

class cVolumeEsfera {
public:
    cVolumeEsfera();
    cVolumeEsfera(const cVolumeEsfera& orig);
    virtual ~cVolumeEsfera();
    
    void lerDados();
    float calcularVol(float raio);
    
private:

};

#endif /* CVOLUMEESFERA_H */

