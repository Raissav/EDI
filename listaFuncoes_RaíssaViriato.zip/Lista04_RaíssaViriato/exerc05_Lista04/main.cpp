#include <cstdlib>

#include "cVolumeEsfera.h"

using namespace std;

/*
 Faça uma função que recebe por parâmetro o raio de uma esfera e calcula o seu 
 volume (v = 4/3 PI * R^3)
 */

int main(int argc, char** argv) {

    cVolumeEsfera obj;
    obj.lerDados();
    
    return 0;
}