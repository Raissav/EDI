#include "cVolumeEsfera.h"
#include <iostream>
#include <math.h>

using namespace std;

cVolumeEsfera::cVolumeEsfera() {
}

cVolumeEsfera::cVolumeEsfera(const cVolumeEsfera& orig) {
}

cVolumeEsfera::~cVolumeEsfera() {
}

void cVolumeEsfera::lerDados(){
    
    float raio;
    cout<<"Informe o raio da esfera: "<<endl;
    cin>>raio;
    cout<<this->calcularVol(raio);
}

float cVolumeEsfera::calcularVol(float raio){
    
    float volume;
    volume = (((4/3)*3,14)*(pow(raio,3)));
    
    return volume;
}