#include <iostream>
#include "cTriangulo.h"

using namespace std;

cTriangulo::cTriangulo() {
}

cTriangulo::cTriangulo(const cTriangulo& orig) {
}

cTriangulo::~cTriangulo() {
}

void cTriangulo::receberValores(){
    
    int x, y, z;
    cout<<"Digite o primeiro lado do triangulo: "<<endl;
    cin>>x;
    cout<<"Digite o segundo lado do triangulo: "<<endl;
    cin>>y;
    cout<<"Digite o terceiro lado do triangulo: "<<endl;
    cin>>z;
    
        if((z<x+y)and(y<x+z)and(x<z+y))
            cout<<this->tipoTriangulo(x, y, z);
            else
                cout<<"Esses numeros não formam um triangulo."<<endl;
        
}

int cTriangulo::tipoTriangulo(int x, int y, int z){
    
    if ((x==y)and(y==z))
        cout<<"Triângulo Equilátero"<<endl;
    
        else if((x==y)or(y==z)or(x==z))
            cout<<"Triângulo Isósceles"<<endl;
        
             else
                cout<<"Triângulo Escaleno"<<endl;
                
}