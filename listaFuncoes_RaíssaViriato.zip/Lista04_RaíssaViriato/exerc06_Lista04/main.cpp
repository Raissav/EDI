#include <cstdlib>

#include "cTriangulo.h"

using namespace std;

/*
  Escreva um procedimento que recebes 3 valores reais X, Y e Z e que verifique 
  se esses valores podem ser os comprimentos dos lados de um triângulo e, neste
  caso, retornar qual o tipo de triângulo formado. Para que X, Y e Z formem um 
  triângulo é necessário que a seguinte propriedade seja satisfeita: o 
  comprimento de cada lado de um triângulo é menor do que a soma do comprimento
  dos outros dois lados. O procedimento deve identificar o tipo de triângulo
  formado observando as seguintes definições:
 */
int main(int argc, char** argv) {

    cTriangulo *objTriangulo = new cTriangulo();
    objTriangulo->receberValores();
    
    return 0;
}

