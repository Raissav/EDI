#ifndef CTRIANGULO_H
#define CTRIANGULO_H

class cTriangulo {
public:
    cTriangulo();
    cTriangulo(const cTriangulo& orig);
    virtual ~cTriangulo();
    
    void receberValores();
    int tipoTriangulo(int x, int y, int z);
    
private:

};

#endif /* CTRIANGULO_H */

