#include "cBhaskara.h"
#include <iostream>
#include <math.h>

using namespace std;

cBhaskara::cBhaskara() {
}

cBhaskara::cBhaskara(const cBhaskara& orig) {
}

cBhaskara::~cBhaskara() {
}
void cBhaskara::lerNumeros(){
    
    cout<< "Digite valor de a:"<<endl;
    cin>>this->a;
    cout<< "Digite valor de b:"<<endl;
    cin>>this->b;
    cout<< "Digite valor de c:"<<endl;
    cin>>this->c;
    
    cout<<this->fDelta(this->a, this->b, this->c);
}

int cBhaskara::fDelta(int a, int b, int c){
    
    int delta;
    delta = pow( b ,2) - 4 * a * c;
    
    return delta;
}

