#ifndef CBHASKARA_H
#define CBHASKARA_H

class cBhaskara {
public:
    
    int a, b, c;
    
    cBhaskara();
    cBhaskara(const cBhaskara& orig);
    virtual ~cBhaskara();
    
    void lerNumeros();
    int fDelta(int a,int b, int c);
    
private:

};

#endif /* CBHASKARA_H */
