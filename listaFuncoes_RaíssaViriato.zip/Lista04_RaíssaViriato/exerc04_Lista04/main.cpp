#include <cstdlib>

#include "cBhaskara.h"

using namespace std;

/*
 Crie uma função que receba três valores, 'a', 'b' e 'c', que são os coeficientes
 de uma equação do segundo grau e retorne o valor do delta, que é dado por 'b² – 4ac'
 */

int main(int argc, char** argv) {

    cBhaskara obj;
    obj.lerNumeros();
    
    return 0;
}
