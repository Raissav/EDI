#include <cstdlib>

#include "cNumeroMenor.h"

using namespace std;

/*
 Escreva uma função que receba dois números inteiros retorne o menor número
 */
int main(int argc, char** argv) {
    
    cNumeroMenor *objNumeroMenor = new cNumeroMenor();
    objNumeroMenor.lerNumeros();

    return 0;
}

