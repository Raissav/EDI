#include "cNumeroMenor.h"
#include <iostream>

using namespace std;

cNumeroMenor::cNumeroMenor() {
}

cNumeroMenor::cNumeroMenor(const cNumeroMenor& orig) {
}

cNumeroMenor::~cNumeroMenor() {
}

void cNumeroMenor::lerNumeros(){
    
    int num1, num2;
    cout<<"Digite seu primeiro numero:"<<endl;
    cin>>num1;
    cout<<"Digite seu segundoo numero:"<<endl;
    cin>>num2;
    cout<<this->devolverNum(num1, num2);
}

int cNumeroMenor::devolverNum(int num1, int num2){
    
    if (num1 < num2){
        cout<<"O numero menor é: "<<num1<<endl;    
    }
    else
        cout<<"O numero menor é: "<<num2<<endl;
}

