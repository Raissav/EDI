
#ifndef CNUMEROMENOR_H
#define CNUMEROMENOR_H

class cNumeroMenor {
public:
    cNumeroMenor();
    cNumeroMenor(const cNumeroMenor& orig);
    virtual ~cNumeroMenor();
    
    void lerNumeros();
    int devolverNum(int num1, int num2);
    
private:

};

#endif /* CNUMEROMENOR_H */

