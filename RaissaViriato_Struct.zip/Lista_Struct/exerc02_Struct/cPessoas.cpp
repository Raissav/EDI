#include "cPessoas.h"
#include <iostream>
#include <math.h>

using namespace std;

cPessoas::cPessoas() {
}

cPessoas::cPessoas(const cPessoas& orig) {
}

cPessoas::~cPessoas() {
}

void cPessoas::lerDados(){
    char opcao;
    int limite =0;
    do{
        cout<<"Digite seu nome"<<endl;
        cin>>this->vetPessoas[limite].nome;
        cout<<"Digite sua altura"<<endl;
        cin>>this->vetPessoas[limite].altura;
        cout<<"Digite seu peso"<<endl;
        cin>>this->vetPessoas[limite].peso;
        cout<<"Digite seu CPF"<<endl;
        cin>>this->vetPessoas[limite].cpf;
        cout<<"Digite seu sexo"<<endl;
        cin>>this->vetPessoas[limite].sexo;
        cout<<"Digite sua matricula"<<endl;
        cin>>this->vetPessoas[limite].matricula;
        
        cout<<"Digite S para continuar o cadastro"<<endl;
        cin>>opcao;
        limite++;
        
    }while((opcao=='S')&&(limite<3));
     
     this->ordenacaoBolha(limite);
     this->imprimirPessoas(limite);
    
    int cpfbusca;
    cout<<"Digite o CPF para buscar"<<endl;
    cin>>cpfbusca;
    if ((this->localizacBinariaIMC(limite, cpfbusca))!=-1)
        cout<<"Aluno encontrado";
    else
        cout<<"Aluno inexistente";
    
    cout<<this->localizacSequencialIMC(limite,cpfbusca);
   
}

float cPessoas::localizacSequencialIMC(int limite, int cpfbusca){
    float imc;
    
    for(int i=0; i<limite; i++){
        if(cpfbusca==this->vetPessoas[i].cpf){
            imc = (this->vetPessoas[i].peso/pow(this->vetPessoas[i].altura,2));
        }
        return imc;
    }    
}

int cPessoas::localizacBinariaIMC(int Contador, int cpfbusca){
    int inf, sup, meio;
    inf= 0;
    sup= Contador-1;
    while (inf<=sup){
        meio=(inf+sup)/2;
        if (cpfbusca==this->vetPessoas[meio].cpf)
            return meio;
        else if (cpfbusca < this->vetPessoas[meio].cpf)
            sup=meio-1;
        else
            inf=meio+1;
    }
    return -1;
}

void cPessoas::ordenacaoBolha(int limite){
    int i,j;
    int temp;
    for (i=limite-1; i>=1; i--){
        for(j=0; j<i; j++){
            if(this->vetPessoas[j].cpf < this->vetPessoas[j+1].cpf){
                temp = this->vetPessoas[j].cpf;
                this->vetPessoas[j].cpf = this->vetPessoas[j+1].cpf;
                this->vetPessoas[j+1].cpf = temp;
            }
        }
    }
}

void cPessoas::imprimirPessoas(int limite){
    for (int i=0; i<=limite; i++)
        cout<<this->vetPessoas[i].cpf;   
}