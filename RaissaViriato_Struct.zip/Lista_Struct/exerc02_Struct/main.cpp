#include <cstdlib>
#include <iostream>
#include "cPessoas.h"

using namespace std;

/*
 Escrever um programa que cadastre o nome, a altura, o peso, o cpf e sexo de
 algumas pessoas. Localize uma pessoa por meio do seu CPF e imprimir o seu IMC.
 */
int main(int argc, char** argv) {

    cPessoas *objP = new cPessoas();
    objP->lerDados();
    
    return 0;
}

