#ifndef CPESSOAS_H
#define CPESSOAS_H

class cPessoas {
public:
    
    cPessoas();
    cPessoas(const cPessoas& orig);
    virtual ~cPessoas();
   
    struct Pessoas{
        char nome[40];
        char sexo;
        float altura, peso;
        int cpf, matricula;
    }vetPessoas[3];
   
    void lerDados();
    float localizacSequencialIMC(int limite, int cpfaux);
    int localizacBinariaIMC(int limite, int cpfaux);
    void ordenacaoBolha(int limite);
    void imprimirPessoas(int limite);
    
private:

};

#endif /* CPESSOAS_H */

