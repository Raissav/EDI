#include "cProduto.h"
#include <iostream>

using namespace std;


cProduto::cProduto() {
}

cProduto::cProduto(const cProduto& orig) {
}

cProduto::~cProduto() {
}

void cProduto::lerDados(){
    char opcao;
    
    do{
        cout<<"Digite o nome do produto:"<<endl;
        cin>>this->vetProdutos[limite].produto;
        cout<<"Digite seu codigo:"<<endl;
        cin>>this->vetProdutos[limite].codigo;
        cout<<"Digite seu valor:"<<endl;
        cin>>this->vetProdutos[limite].preco;
        
        cout<<"Digite S para continuar o cadastro"<<endl;
        cin>>opcao;
        limite++;
        
    }while((opcao=='S')&&(limite<3));
         
    int produtobusca;
    cout<<"Digite o codigo para buscar o produto"<<endl;
    cin>>produtobusca;
    
    if ((this->localizaProdutos(limite, produtobusca))==-1)
        cout<<"Produto inexistente";
    else
        cout<<"Produto encontrado";
    
}

void cProduto::localizaProdutos(int limite, int produtobusca){
        
    for(int i=0; i<limite; i++){
        if(produtobusca==this->vetProdutos[i].codigo)
            cout<<this->vetProdutos[i].preco<<endl; 
        else
            return -1;
    }    
    
};

void cProduto::imprimirProdutos(){
    
    for (int i=0; i<=limite; i++){
        cout<<this->vetProdutos[i].codigo<<"-----------"<<this->vetProdutos[i].produto<<endl;
    }
}
