#include <cstdlib>

#include "cProduto.h"

using namespace std;

/*
 Escrever um programa que cadastre vários produtos. Em seguida, imprima uma 
 lista com o código e nome da cada produto. Por último, consulte o preço de um 
 produto através de seu código.
 */

int main(int argc, char** argv) {
    
    cProduto *objP = new cProduto();
    objP->lerDados();
    objP->imprimirProdutos();
    objP->localizaProduto();
    
    return 0;
}

