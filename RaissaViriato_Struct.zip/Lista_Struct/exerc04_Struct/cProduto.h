#ifndef CPRODUTO_H
#define CPRODUTO_H

class cProduto {
public:
    cProduto();
    cProduto(const cProduto& orig);
    virtual ~cProduto();   
    
    struct Produto{
        char produto[40];
        float preco;
        int codigo;
    }vetProdutos[3];
   
    int limite =0;
    void lerDados();
    void imprimirProdutos();
    void localizaProdutos(int limite, int produtobusca);
    

private:

};


#endif /* CPRODUTO_H */

