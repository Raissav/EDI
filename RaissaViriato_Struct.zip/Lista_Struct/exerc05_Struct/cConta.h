#ifndef CCONTA_H
#define CCONTA_H

class cConta {
public:
    cConta();
    cConta(const cConta& orig);
    virtual ~cConta();
    
    struct Cliente{
        char nome[40];
        int cpf, depositoI;
    }dadosCliente[3];
    
    void lerDados();
    float saldoConta();
    
private:
    

};

#endif /* CCONTA_H */

