#include "cConta.h"
#include <iostream>

using namespace std;

cConta::cConta() {
}

cConta::cConta(const cConta& orig) {
}

cConta::~cConta() {
}

void cConta::lerDados(){
    
    for(int i=0;i<3;i++){
    cout<<"Informe o nome do cliente nº"<<i<<endl;
    cin>>dadosCliente[i].nome;
    cout<<"Informe o CPF do cliente nº"<<i<<endl;
    cin>>dadosCliente[i].cpf;
    cout<<"Informe o deposito inicial do cliente nº"<<i<<endl;
    cin>>dadosCliente[i].depositoI;
    }
    cout<<this->saldoConta();
}

float cConta::saldoConta(){
    float saldoFinal,quantia;
    char acao;
    int buscarCpf;
    
    cout<<"Digite o CPF do cliente que deseja acessar a conta:"<<endl;
    cin>>buscarCpf;
    
    for(int i=0;i<3;i++){
        if(buscarCpf==dadosCliente[i].cpf)do{
            cout<<"Digite 'D' para deposito e 'S' para saque"<<endl;

            if (acao== 'D' or 'd'){
                cout<<"Digite a quantia que deseja depositar: ";
                cin>>quantia;
                saldoFinal = dadosCliente[i].depositoI + quantia;
            }
                else if(acao == 'S' or 's'){
                    cout<<"Digite a quantia que deseja sacar: ";
                    cin>>quantia;
                    saldoFinal = dadosCliente[i].depositoI - quantia;
                }
                    else{
                        cout<<"opcao invalida";
                    }
            cout<<dadosCliente[i].nome<<endl;
            cout<<saldoFinal;
        }  
    }    
}
