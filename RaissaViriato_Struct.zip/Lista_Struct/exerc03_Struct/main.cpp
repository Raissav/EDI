#include <cstdlib>
#include <iostream>
#include "cPessoas.h"

using namespace std;

/*
 Implemente a pesquisa de pessoas por meio do CPF. Programar com a pesquisa sequencial
 e pesquisa binária.
 */
int main(int argc, char** argv) {
    
    cPessoas *objP = new cPessoas();
    objP->lerDados();
    
    return 0;
}

