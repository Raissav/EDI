#include <cstdlib>
#include <iostream>
#include "cAluno.h"

using namespace std;

/*
 Escrever um programa que cadastre o nome, a matrícula e duas notas de vários 
 alunos. Em seguida imprima a matrícula, o nome e a média de cada um deles.
 */
int main(int argc, char** argv) {
 
    cAluno *objA = new cAluno();
    objA->lerDados();
    objA->imprimirAlunos();
    
    return 0;
}

