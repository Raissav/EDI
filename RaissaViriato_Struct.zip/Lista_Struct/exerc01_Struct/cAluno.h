#ifndef CALUNO_H
#define CALUNO_H

class cAluno {
public:
    cAluno();
    cAluno(const cAluno& orig);
    virtual ~cAluno();
    
    struct Alunos{
        char nome[40];
        float n1, n2;
        int matricula;
    }vetAlunos[3];
   
    int limite =0;
    void lerDados();
    void imprimirAlunos();
    

private:

};

#endif /* CALUNO_H */
   