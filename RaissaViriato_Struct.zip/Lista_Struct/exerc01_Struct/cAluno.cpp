#include "cAluno.h"
#include <iostream>

using namespace std;

cAluno::cAluno() {
}

cAluno::cAluno(const cAluno& orig) {
}

cAluno::~cAluno() {
}

void cAluno::lerDados(){
    char opcao;
    
    do{
        cout<<"Digite seu nome"<<endl;
        cin>>this->vetAlunos[limite].nome;
        cout<<"Digite sua matricula"<<endl;
        cin>>this->vetAlunos[limite].matricula;
        cout<<"Digite sua primeira nota"<<endl;
        cin>>this->vetAlunos[limite].n1;
        cout<<"Digite sua segunda nota"<<endl;
        cin>>this->vetAlunos[limite].n2;
        
        cout<<"Digite S para continuar o cadastro"<<endl;
        cin>>opcao;
        limite++;
        
    }while((opcao=='S')&&(limite<3));
     
}

void cAluno::imprimirAlunos(){
    float media;
    for (int i=0; i<=limite; i++){
        media = (vetAlunos[i].n1+vetAlunos[i].n2)/2;
        cout<<this->vetAlunos[i].matricula<<" "<<endl;
        cout<<"A media deste aluno é "<< media<<endl;
    }
}